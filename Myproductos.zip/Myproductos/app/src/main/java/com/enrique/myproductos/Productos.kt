package com.enrique.myproductos


data class Productos(
    val ID: String,
    val descripcion: String,
    val  menudeo: String,
    val mayoreo: String
)

